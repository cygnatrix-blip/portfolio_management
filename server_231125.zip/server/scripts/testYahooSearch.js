const yahooFinance = require('yahoo-finance2').default;

async function searchHDFCAMC() {
  try {
    const results = await yahooFinance.search('HDFCAMC', { newsCount: 0 });
    
    console.log('\n=== ALL RESULTS ===');
    console.log(JSON.stringify(results.quotes, null, 2));

    console.log('\n=== FILTERED NSE RESULTS ===');
    const filtered = results.quotes
      .filter(q => q && q.symbol && (q.exchDisp === 'NSI' || q.exchDisp === 'NSE' || q.symbol.endsWith('.NS')))
      .map(q => ({
        symbol: q.symbol,
        name: q.longname || q.shortname || q.symbol,
        exchange: q.exchDisp
      }));
    
    console.table(filtered);

  } catch (error) {
    console.error('Error:', error);
  }
}

searchHDFCAMC();
