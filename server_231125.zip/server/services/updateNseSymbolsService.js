// server/services/updateNseSymbolsService.js
const axios = require('axios');
const csv = require('csv-parser');
const db = require('../config/db');
const { Readable } = require('stream');

/**
 * Updates NSE Symbol Master List
 * Source: NSE India official equity list
 * Runs: Weekly (symbols don't change frequently)
 */
const updateNseSymbols = async () => {
  console.log('--- Starting NSE Symbol Master Update ---');
  
  try {
    // NSE provides equity symbol list
    const nseSymbolUrl = 'https://nsearchives.nseindia.com/content/equities/EQUITY_L.csv';
    
    console.log('Downloading NSE Equity Symbol List...');
    const response = await axios.get(nseSymbolUrl, {
      headers: {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
        'Accept': 'text/csv'
      },
      responseType: 'text'
    });

    const csvData = response.data;
    
    return new Promise((resolve, reject) => {
      const results = [];
      const stream = Readable.from(csvData);
      
      stream
        .pipe(csv({
          mapHeaders: ({ header }) => header.trim().toUpperCase(),
          skipLines: 0
        }))
        .on('data', (row) => {
          // NSE CSV columns: SYMBOL, NAME OF COMPANY, SERIES, DATE OF LISTING, PAID UP VALUE, MARKET LOT, ISIN NUMBER, FACE VALUE
          const symbol = row.SYMBOL || row['SYMBOL'];
          const companyName = row['NAME OF COMPANY'] || row.NAME || row['COMPANY NAME'];
          const series = row.SERIES || row[' SERIES'];
          const isin = row['ISIN NUMBER'] || row.ISIN || row['ISIN NO'];
          
          if (symbol && companyName) {
            results.push({
              ticker: symbol.trim(),
              company_name: companyName.trim(),
              series: series ? series.trim() : null,
              isin: isin ? isin.trim() : null
            });
          }
        })
        .on('end', async () => {
          console.log(`Parsed ${results.length} symbols from NSE.`);
          
          let insertedCount = 0;
          let updatedCount = 0;
          let errorCount = 0;
          
          for (const symbol of results) {
            try {
              const sql = `
                INSERT INTO nse_symbols (ticker, company_name, series, isin, last_updated)
                VALUES ($1, $2, $3, $4, CURRENT_DATE)
                ON CONFLICT (ticker) DO UPDATE SET
                  company_name = EXCLUDED.company_name,
                  series = EXCLUDED.series,
                  isin = EXCLUDED.isin,
                  last_updated = CURRENT_DATE
                RETURNING (xmax = 0) AS inserted;
              `;
              
              const result = await db.query(sql, [
                symbol.ticker,
                symbol.company_name,
                symbol.series,
                symbol.isin
              ]);
              
              if (result.rows[0].inserted) {
                insertedCount++;
              } else {
                updatedCount++;
              }
            } catch (insertError) {
              console.error(`Error inserting ${symbol.ticker}:`, insertError.message);
              errorCount++;
            }
          }
          
          console.log(`✅ NSE Symbols Updated:`);
          console.log(`   - New: ${insertedCount}`);
          console.log(`   - Updated: ${updatedCount}`);
          console.log(`   - Errors: ${errorCount}`);
          console.log(`   - Total in database: ${insertedCount + updatedCount}`);
          
          resolve();
        })
        .on('error', (error) => {
          console.error('CSV parsing error:', error);
          reject(error);
        });
    });
    
  } catch (error) {
    console.error('Failed to update NSE symbols:', error.message);
    // Don't throw - symbol update is not critical for daily operations
    console.log('Continuing without symbol update...');
  }
};

/**
 * Check if symbols need update (weekly)
 */
const shouldUpdateSymbols = async () => {
  try {
    const result = await db.query(
      'SELECT MAX(last_updated) as last_update FROM nse_symbols'
    );
    
    if (!result.rows[0].last_update) {
      console.log('No symbols found - will update now.');
      return true;
    }
    
    const lastUpdate = new Date(result.rows[0].last_update);
    const daysSinceUpdate = Math.floor((new Date() - lastUpdate) / (1000 * 60 * 60 * 24));
    
    if (daysSinceUpdate >= 7) {
      console.log(`Symbols last updated ${daysSinceUpdate} days ago - will update now.`);
      return true;
    }
    
    console.log(`Symbols updated ${daysSinceUpdate} days ago - no update needed.`);
    return false;
  } catch (error) {
    console.error('Error checking symbol update status:', error.message);
    return true; // Update on error to be safe
  }
};

module.exports = {
  updateNseSymbols,
  shouldUpdateSymbols
};
