const db = require('../config/db');

/**
 * @desc    Get overall dashboard data for all of an investor's portfolios
 * @route   GET /api/dashboard/overall
 */
const getOverallDashboard = async (req, res) => {
    const userId = req.user.id;
    try {
        // This query joins across all of the user's portfolios to get aggregate stats
        const query = `
            WITH PortfolioStats AS (
                -- 1. Get the latest NAV record for each portfolio
                SELECT
                    p.id AS portfolio_id,
                    p.name,
                    p.created_at,
                    (SELECT nav.total_portfolio_value 
                     FROM nav_history nav 
                     WHERE nav.portfolio_id = p.id 
                     ORDER BY nav.nav_date DESC 
                     LIMIT 1) AS total_portfolio_value
                FROM portfolios p
                WHERE p.user_id = $1
            ),
            PortfolioInvestment AS (
                -- 2. Get the total net investment (cost) for each portfolio
                SELECT
                    portfolio_id,
                    COALESCE(SUM(CASE WHEN transaction_type = 'DEPOSIT' THEN amount ELSE -amount END), 0) AS total_investment
                FROM units_ledger
                WHERE portfolio_id IN (SELECT portfolio_id FROM PortfolioStats)
                GROUP BY portfolio_id
            ),
            PortfolioUnits AS (
                -- 3. Get the total net units for each portfolio
                SELECT
                    portfolio_id,
                    COALESCE(SUM(CASE WHEN transaction_type = 'DEPOSIT' THEN units ELSE -units END), 0) AS total_units
                FROM units_ledger
                WHERE portfolio_id IN (SELECT portfolio_id FROM PortfolioStats)
                GROUP BY portfolio_id
            )
            -- 4. Combine all stats
            SELECT
                ps.portfolio_id,
                ps.name,
                ps.created_at,
                COALESCE(ps.total_portfolio_value, 0) AS "currentValue",
                COALESCE(pi.total_investment, 0) AS "totalInvestment",
                COALESCE(pu.total_units, 0) AS "totalUnits"
            FROM PortfolioStats ps
            LEFT JOIN PortfolioInvestment pi ON ps.portfolio_id = pi.portfolio_id
            LEFT JOIN PortfolioUnits pu ON ps.portfolio_id = pu.portfolio_id;
        `;

        const { rows: portfolios } = await db.query(query, [userId]);

        // 5. Calculate overall totals
        let overallTotalValue = 0;
        let overallTotalInvestment = 0;
        let overallTotalUnits = 0;

        // Also add the new Avg NAV to each individual portfolio
        const portfoliosWithAvgNav = portfolios.map(p => {
            const currentValue = parseFloat(p.currentValue);
            const totalInvestment = parseFloat(p.totalInvestment);
            const totalUnits = parseFloat(p.totalUnits);

            overallTotalValue += currentValue;
            overallTotalInvestment += totalInvestment;
            overallTotalUnits += totalUnits;

            return {
                ...p,
                currentValue: currentValue,
                totalInvestment: totalInvestment,
                totalUnits: totalUnits,
                avgNav: (totalUnits > 0) ? (totalInvestment / totalUnits) : 0, // <-- Avg NAV per portfolio
                absoluteGain: currentValue - totalInvestment,
            };
        });

        const overallAbsoluteGain = overallTotalValue - overallTotalInvestment;
        
        // 6. NEW: Calculate Overall Average NAV (Cost per Unit)
        const overallAvgNav = (overallTotalUnits > 0) ? (overallTotalInvestment / overallTotalUnits) : 0;

        res.json({
            portfolios: portfoliosWithAvgNav, // List of all portfolios and their individual values + avgNav
            overall: {
                currentValue: overallTotalValue,
                totalInvestment: overallTotalInvestment,
                absoluteGain: overallAbsoluteGain,
                totalUnits: overallTotalUnits,
                avgNav: overallAvgNav // <-- NEW METRIC
            }
        });

    } catch (err) {
        console.error('DB Error in getOverallDashboard:', err.message);
        res.status(500).json({ error: 'Server Error', details: err.message });
    }
};

/**
 * @desc    Get specific dashboard data for a *single* portfolio
 * @route   GET /api/dashboard/portfolio/:id
 */
const getPortfolioDashboard = async (req, res) => {
    const portfolioId = req.params.id;
    const userId = req.user.id;

    try {
        // 0. Verify user owns this portfolio
        const portfolioResult = await db.query('SELECT * FROM portfolios WHERE id = $1 AND user_id = $2', [portfolioId, userId]);
        if (portfolioResult.rows.length === 0) {
            return res.status(404).json({ error: 'Portfolio not found or you are not the owner.' });
        }

        // 1. Get latest NAV for THIS portfolio
        const navResult = await db.query(
            'SELECT * FROM nav_history WHERE portfolio_id = $1 ORDER BY nav_date DESC LIMIT 1',
            [portfolioId]
        );
        const latestNav = navResult.rows.length > 0 ? navResult.rows[0] : null;

        // 2. Get NAV History for THIS portfolio
        const navHistoryResult = await db.query(
            'SELECT nav_date, nav_value FROM nav_history WHERE portfolio_id = $1 ORDER BY nav_date ASC',
            [portfolioId]
        );
        const navHistory = navHistoryResult.rows;

        // 3. Get Investment Summary for THIS portfolio
        const ledgerSummaryResult = await db.query(
            `SELECT 
                COALESCE(SUM(CASE WHEN transaction_type = 'DEPOSIT' THEN amount ELSE -amount END), 0) AS "totalInvestment",
                COALESCE(SUM(CASE WHEN transaction_type = 'DEPOSIT' THEN units ELSE -units END), 0) AS "totalUnits"
             FROM units_ledger
             WHERE portfolio_id = $1`,
            [portfolioId]
        );
        
        const { totalInvestment, totalUnits } = ledgerSummaryResult.rows[0];

        // 4. NEW: Calculate Average NAV (Cost per Unit) for THIS portfolio
        const avgNavValue = (totalUnits > 0) ? (totalInvestment / totalUnits) : 0;
        
        // 5. Calculate Gains
        const totalPortfolioValue = latestNav ? parseFloat(latestNav.total_portfolio_value) : 0;
        const absoluteCapitalGain = totalPortfolioValue - totalInvestment;
        const absoluteCapitalPercentage = (totalInvestment > 0) ? (absoluteCapitalGain / totalInvestment) * 100 : 0;


        // 6. Holdings calculation for THIS portfolio
        const holdingsResult = await db.query(
            'SELECT * FROM master_holdings WHERE quantity > 0 AND portfolio_id = $1',
            [portfolioId]
        );
        const holdings = holdingsResult.rows;
        let holdingsWithValue = [];

        if (latestNav && holdings.length > 0) {
            for (const holding of holdings) {
                let value = 0;
                if (holding.ticker === 'CASH') {
                    value = parseFloat(holding.quantity);
                } else {
                    // Daily prices are global
                    const priceResult = await db.query(
                        'SELECT closing_price FROM daily_prices WHERE ticker = $1 AND price_date <= $2 ORDER BY price_date DESC LIMIT 1',
                        [holding.ticker, latestNav.nav_date]
                    );
                    if (priceResult.rows.length > 0) {
                        value = parseFloat(holding.quantity) * parseFloat(priceResult.rows[0].closing_price);
                    }
                }
                holdingsWithValue.push({
                    name: holding.ticker,
                    value: parseFloat(value.toFixed(2)),
                });
            }

            holdingsWithValue = holdingsWithValue.map((holding) => ({
                ...holding,
                percentage: totalPortfolioValue > 0 ? (holding.value / totalPortfolioValue) * 100 : 0,
            }));
        }

        // 7. Global Market Data (no change)
        const niftyHistoryResult = await db.query(
            `SELECT price_date AS "date", closing_price AS "price" FROM index_history WHERE symbol = 'NIFTY50' ORDER BY price_date ASC`
        );
        const nifty500HistoryResult = await db.query(
            `SELECT price_date AS "date", closing_price AS "price" FROM index_history WHERE symbol = 'NIFTY500' ORDER BY price_date ASC`
        );
        
        // 8. Build final response
        const response = {
            portfolioName: portfolioResult.rows[0].name,
            latestNav: latestNav ? parseFloat(latestNav.nav_value) : 10,
            avgNav: avgNavValue, // <-- NEW METRIC
            totalPortfolioValue: totalPortfolioValue,
            totalInvestment: parseFloat(totalInvestment),
            absoluteCapitalGain: parseFloat(absoluteCapitalGain),
            absoluteCapitalPercentage: parseFloat(absoluteCapitalPercentage),
            totalUnits: parseFloat(totalUnits),
            holdings: holdingsWithValue,
            navHistory: navHistory,
            niftyHistory: niftyHistoryResult.rows,
            nifty500History: nifty500HistoryResult.rows,
        };

        console.log(`✅ Portfolio Dashboard for ID ${portfolioId} fetched successfully`);
        res.json(response);
        
    } catch (err) {
        console.error('❌ DB Error in getPortfolioDashboard:', err.message);
        res.status(500).json({ 
            error: 'Server Error',
            details: err.message,
            timestamp: new Date().toISOString()
        });
    }
};

module.exports = {
  getOverallDashboard,
  getPortfolioDashboard
};