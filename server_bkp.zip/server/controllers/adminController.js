const db = require('../config/db');
const bcrypt = require('bcryptjs');

/**
 * @desc    Get admin dashboard data (total investors)
 * @route   GET /api/admin/dashboard
 */
const getAdminDashboard = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT COUNT(*) FROM users WHERE role = 'investor'");
        res.json({ totalInvestors: parseInt(rows[0].count, 10) });
    } catch (err) {
        console.error('DB Error in getAdminDashboard:', err.message);
        res.status(500).send('Server Error');
    }
};

/**
 * @desc    Get all investors
 * @route   GET /api/admin/users
 */
const getAllInvestors = async (req, res) => {
    try {
        const { rows } = await db.query("SELECT id, name, email, created_at FROM users WHERE role = 'investor' ORDER BY name");
        res.json(rows);
    } catch (err) {
        console.error('DB Error in getAllInvestors:', err.message);
        res.status(500).send('Server Error');
    }
};

/**
 * @desc    Admin creates a new investor
 * @route   POST /api/admin/users
 */
const createInvestor = async (req, res) => {
  const { name, email, password } = req.body;

  if (!name || !email || !password) {
    return res.status(400).json({ msg: 'Please provide name, email, and password' });
  }

  try {
    const userExists = await db.query('SELECT * FROM users WHERE email = $1', [email]);
    if (userExists.rows.length > 0) {
      return res.status(400).json({ msg: 'User with that email already exists' });
    }

    const salt = await bcrypt.genSalt(10);
    const hashedPassword = await bcrypt.hash(password, salt);

    // Add user with 'investor' role
    const sql = `
      INSERT INTO users (name, email, password, role) 
      VALUES ($1, $2, $3, 'investor') 
      RETURNING id, name, email, role
    `;
    const { rows } = await db.query(sql, [name, email, hashedPassword]);
    
    res.status(201).json(rows[0]);

  } catch (err) {
    console.error('DB Error in createInvestor:', err.message);
    res.status(500).send('Server Error');
  }
};

/**
 * @desc    Admin resets an investor's password
 * @route   PUT /api/admin/users/reset-password
 */
const resetInvestorPassword = async (req, res) => {
    const { userId, newPassword } = req.body;

    if (!userId || !newPassword) {
      return res.status(400).json({ msg: 'User ID and new password are required.' });
    }

    try {
        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(newPassword, salt);

        // Update password for the specified user ID
        const sql = `
          UPDATE users SET password = $1 
          WHERE id = $2 AND role = 'investor'
          RETURNING id, name, email
        `;
        const { rows } = await db.query(sql, [hashedPassword, userId]);

        if (rows.length === 0) {
            return res.status(404).json({ msg: 'Investor not found' });
        }

        res.json({ msg: 'Password updated successfully for ' + rows[0].name });
    } catch (err) {
        console.error('DB Error in resetInvestorPassword:', err.message);
        res.status(500).send('Server Error');
    }
};

/**
 * @desc    Admin deletes an investor
 * @route   DELETE /api/admin/users/:id
 */
const deleteInvestor = async (req, res) => {
    const { id } = req.params;
    try {
        // Deleting the user will also delete all their portfolios
        // and associated data due to "ON DELETE CASCADE" in the database.
        const deleteResult = await db.query(
            "DELETE FROM users WHERE id = $1 AND role = 'investor' RETURNING *", 
            [id]
        );
        if (deleteResult.rowCount === 0) {
            return res.status(404).json({ msg: 'Investor not found' });
        }
        res.json({ msg: 'Investor and all their portfolios deleted.' });
    } catch (err) {
        console.error('DB Error in deleteInvestor:', err.message);
        res.status(500).send('Server Error');
    }
};

module.exports = {
  getAdminDashboard,
  getAllInvestors,
  createInvestor,
  resetInvestorPassword,
  deleteInvestor
};