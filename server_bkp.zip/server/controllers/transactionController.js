const db = require('../config/db');

/**
 * @desc    Helper to check if user owns the portfolio
 */
const checkPortfolioOwner = async (dbClient, portfolioId, userId) => {
    const { rows } = await dbClient.query('SELECT user_id FROM portfolios WHERE id = $1', [portfolioId]);
    if (rows.length === 0) throw new Error('Portfolio not found.');
    if (rows[0].user_id !== userId) throw new Error('You are not authorized to manage this portfolio.');
    return true;
};

/**
 * @desc    Process a new unified transaction (BUY, SELL, DEPOSIT, WITHDRAWAL)
 * @route   POST /api/transactions
 */
const createTransaction = async (req, res) => {
    const dbClient = await db.pool.connect(); // Get a client from the pool
    const userId = req.user.id; // <-- Get User ID from middleware

    // Destructure all possible fields from body
    const { 
        transaction_type: type,
        ticker, 
        quantity, 
        price_per_share, 
        total_value, 
        portfolio_id,
        amount 
    } = req.body;

    if (!portfolio_id) {
        return res.status(400).json({ success: false, message: 'portfolio_id is required for all transactions.' });
    }
    if (!type) {
        return res.status(400).json({ success: false, message: 'transaction_type is required.' });
    }

    let portfolioIdInt;
    try {
        portfolioIdInt = parseInt(portfolio_id, 10);
        if (isNaN(portfolioIdInt)) throw new Error();
    } catch (e) {
        return res.status(400).json({ success: false, message: 'Invalid portfolio_id.' });
    }


    try {
        await dbClient.query('BEGIN'); // Start transaction
        
        // Check ownership *inside* the transaction
        await checkPortfolioOwner(dbClient, portfolioIdInt, userId);

        let resultData;

        // --- 1. DEPOSIT LOGIC ---
        if (type === 'DEPOSIT') {
            if (!amount || parseFloat(amount) <= 0) {
                throw new Error('A valid, positive Amount is required for DEPOSIT.');
            }
            
            const parsedAmount = parseFloat(amount);
            
            // Get the latest NAV record for this portfolio, and lock the row for update
            const lastNavResult = await dbClient.query(
                'SELECT * FROM nav_history WHERE portfolio_id = $1 ORDER BY nav_date DESC LIMIT 1 FOR UPDATE',
                [portfolioIdInt]
            );
            
            if (lastNavResult.rows.length === 0) {
                 throw new Error('Portfolio has no NAV history. This should not happen if portfolio was initialized correctly.');
            }

            let latestNAV = parseFloat(lastNavResult.rows[0].nav_value);
            let totalUnits = parseFloat(lastNavResult.rows[0].total_units_outstanding);
            
            // Calculate new units based on the latest NAV
            const newUnits = parsedAmount / latestNAV;

            // Add to units ledger
            const ledgerRes = await dbClient.query(
                'INSERT INTO units_ledger (portfolio_id, transaction_type, amount, units, transaction_date) VALUES ($1, \'DEPOSIT\', $2, $3, CURRENT_DATE) RETURNING *', 
                [portfolioIdInt, parsedAmount, newUnits]
            );
            resultData = ledgerRes.rows[0];

            // Add cash to holdings
            await dbClient.query(`
               INSERT INTO master_holdings (ticker, quantity, portfolio_id) 
               VALUES ('CASH', $1, $2)
               ON CONFLICT (portfolio_id, ticker) 
               DO UPDATE SET quantity = master_holdings.quantity + $1
            `, [parsedAmount, portfolioIdInt]);

            // Update total units for the fund on the *latest* NAV entry
            const newTotalUnits = totalUnits + newUnits;
            await dbClient.query(
                'UPDATE nav_history SET total_units_outstanding = $1 WHERE id = $2',
                [newTotalUnits, lastNavResult.rows[0].id]
            );

        // --- 2. WITHDRAWAL LOGIC ---
        } else if (type === 'WITHDRAWAL') {
            if (!amount || parseFloat(amount) <= 0) {
                throw new Error('A valid, positive Amount is required for WITHDRAWAL.');
            }
            const parsedAmount = parseFloat(amount);
            
            // Get latest NAV and lock the row
            const lastNavResult = await dbClient.query(
                'SELECT * FROM nav_history WHERE portfolio_id = $1 ORDER BY nav_date DESC LIMIT 1 FOR UPDATE',
                [portfolioIdInt]
            );
            if (lastNavResult.rows.length === 0) throw new Error('No NAV history found.');

            let latestNAV = parseFloat(lastNavResult.rows[0].nav_value);
            let totalUnits = parseFloat(lastNavResult.rows[0].total_units_outstanding);
            const unitsToRedeem = parsedAmount / latestNAV;
            
            // Check if user has enough units
            const clientUnitsResult = await dbClient.query(
                `SELECT COALESCE(SUM(CASE WHEN transaction_type = 'DEPOSIT' THEN units ELSE -units END), 0) as "totalUnits"
                 FROM units_ledger
                 WHERE portfolio_id = $1`,
                [portfolioIdInt]
            );
            const clientTotalUnits = parseFloat(clientUnitsResult.rows[0].totalUnits);
            if (unitsToRedeem > clientTotalUnits) {
                throw new Error('Insufficient units for withdrawal.');
            }

            // Check if fund has enough cash
            const cashResult = await dbClient.query(
                'SELECT quantity FROM master_holdings WHERE ticker = \'CASH\' AND portfolio_id = $1',
                [portfolioIdInt]
            );
            if (cashResult.rows.length === 0 || parseFloat(cashResult.rows[0].quantity) < parsedAmount) {
                throw new Error('Insufficient cash in portfolio for withdrawal.');
            }

            // Add to units ledger
            const ledgerRes = await dbClient.query(
                'INSERT INTO units_ledger (portfolio_id, transaction_type, amount, units, transaction_date) VALUES ($1, \'WITHDRAWAL\', $2, $3, CURRENT_DATE) RETURNING *', 
                [portfolioIdInt, parsedAmount, unitsToRedeem]
            );
            resultData = ledgerRes.rows[0];

            // Remove cash from holdings
            await dbClient.query(
                'UPDATE master_holdings SET quantity = quantity - $1 WHERE ticker = \'CASH\' AND portfolio_id = $2', 
                [parsedAmount, portfolioIdInt]
            );

            // Update total units for the fund on the *latest* NAV entry
            const newTotalUnits = totalUnits - unitsToRedeem;
            await dbClient.query(
                'UPDATE nav_history SET total_units_outstanding = $1 WHERE id = $2',
                [newTotalUnits, lastNavResult.rows[0].id]
            );

        // --- 3. BUY LOGIC ---
        } else if (type === 'BUY') {
            if (!ticker || !quantity || !price_per_share ) throw new Error('Ticker, quantity, and price_per_share are required for BUY.');
            
            const parsedQuantity = parseFloat(quantity);
            const parsedPrice = parseFloat(price_per_share);
            const parsedTotalValue = total_value ? parseFloat(total_value) : parsedQuantity * parsedPrice;

            if (parsedQuantity <= 0 || parsedPrice <= 0) throw new Error('Quantity and Price must be positive numbers.');

            // Check for enough cash
            const cashResult = await dbClient.query(
                'SELECT quantity FROM master_holdings WHERE ticker = \'CASH\' AND portfolio_id = $1',
                [portfolioIdInt]
            );
            if (cashResult.rows.length === 0 || parseFloat(cashResult.rows[0].quantity) < parsedTotalValue) {
                throw new Error('Insufficient cash in portfolio to make this purchase.');
            }

            // Add to asset transactions
            const assetRes = await dbClient.query(
                'INSERT INTO asset_transactions (transaction_type, ticker, quantity, price_per_share, total_value, portfolio_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
                [type, ticker.toUpperCase(), parsedQuantity, parsedPrice, parsedTotalValue, portfolioIdInt]
            );
            resultData = assetRes.rows[0];

            // Add to holdings
            await dbClient.query(`
                INSERT INTO master_holdings (ticker, quantity, portfolio_id) 
                VALUES ($1, $2, $3)
                ON CONFLICT (portfolio_id, ticker) 
                DO UPDATE SET quantity = master_holdings.quantity + $2
            `, [ticker.toUpperCase(), parsedQuantity, portfolioIdInt]);
            
            // Subtract from cash
            await dbClient.query(
                'UPDATE master_holdings SET quantity = quantity - $1 WHERE ticker = \'CASH\' AND portfolio_id = $2',
                [parsedTotalValue, portfolioIdInt]
            );

        // --- 4. SELL LOGIC ---
        } else if (type === 'SELL') {
            if (!ticker || !quantity || !price_per_share ) throw new Error('Ticker, quantity, and price_per_share are required for SELL.');

            const parsedQuantity = parseFloat(quantity);
            const parsedPrice = parseFloat(price_per_share);
            const parsedTotalValue = total_value ? parseFloat(total_value) : parsedQuantity * parsedPrice;

            if (parsedQuantity <= 0 || parsedPrice <= 0) throw new Error('Quantity and Price must be positive numbers.');
            
            // Check for sufficient holdings
            const holdingResult = await dbClient.query(
                'SELECT quantity FROM master_holdings WHERE ticker = $1 AND portfolio_id = $2',
                [ticker.toUpperCase(), portfolioIdInt]
            );
            
            if (holdingResult.rows.length === 0 || parseFloat(holdingResult.rows[0].quantity) < parsedQuantity) {
                throw new Error(`Insufficient holdings of ${ticker} to sell.`);
            }

            // Add to asset transactions
            const assetRes = await dbClient.query(
                'INSERT INTO asset_transactions (transaction_type, ticker, quantity, price_per_share, total_value, portfolio_id) VALUES ($1, $2, $3, $4, $5, $6) RETURNING *',
                [type, ticker.toUpperCase(), parsedQuantity, parsedPrice, parsedTotalValue, portfolioIdInt]
            );
            resultData = assetRes.rows[0];

            // Subtract from holdings
            await dbClient.query(
                'UPDATE master_holdings SET quantity = quantity - $1 WHERE ticker = $2 AND portfolio_id = $3',
                [parsedQuantity, ticker.toUpperCase(), portfolioIdInt]
            );

            // Add to cash
            await dbClient.query(
                'UPDATE master_holdings SET quantity = quantity + $1 WHERE ticker = \'CASH\' AND portfolio_id = $2',
                [parsedTotalValue, portfolioIdInt]
            );
            
        } else {
            throw new Error(`Invalid transaction type specified: ${type}`);
        }

        await dbClient.query('COMMIT');
        res.status(201).json({ success: true, data: resultData, message: `Transaction (${type}) successful.` });

    } catch (err) {
        await dbClient.query('ROLLBACK');
        console.error(`Error in createTransaction (Portfolio ID: ${portfolioIdInt}):`, err.message);
        // Send a 400 (Bad Request) for transaction errors, 500 for others
        res.status(err.message.includes('Insufficient') || err.message.includes('required') ? 400 : 500).json({ success: false, message: err.message });
    } finally {
        dbClient.release(); // Release the client back to the pool
    }
};

/**
 * @desc    Get asset (BUY/SELL) transactions with pagination (scoped to portfolio)
 * @route   GET /api/transactions/:portfolioId
 */
const getAssetTransactions = async (req, res) => {
    const portfolioId = req.params.portfolioId;
    const userId = req.user.id;

    try {
        // Check ownership
        const { rows: portfolioRows } = await db.query('SELECT user_id FROM portfolios WHERE id = $1', [portfolioId]);
        if (portfolioRows.length === 0) {
            return res.status(404).json({ msg: 'Portfolio not found.' });
        }
        if (portfolioRows[0].user_id !== userId) {
            return res.status(403).json({ msg: 'You are not authorized to view these transactions.'});
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        // Filter transactions by portfolioId
        const transactionsResult = await db.query(
            'SELECT * FROM asset_transactions WHERE portfolio_id = $1 ORDER BY transaction_date DESC LIMIT $2 OFFSET $3',
            [portfolioId, limit, offset]
        );

        // Get total count for THIS portfolio
        const totalResult = await db.query(
            'SELECT COUNT(*) FROM asset_transactions WHERE portfolio_id = $1',
            [portfolioId]
        );
        
        res.json({
            transactions: transactionsResult.rows,
            totalItems: parseInt(totalResult.rows[0].count),
            currentPage: page,
            totalPages: Math.ceil(totalResult.rows[0].count / limit),
        });
    } catch (err) {
        console.error('DB Error in getAssetTransactions:', err.message);
        res.status(500).send(err.message);
    }
};

/**
 * @desc    Get ledger (DEPOSIT/WITHDRAWAL) transactions with pagination (scoped to portfolio)
 * @route   GET /api/transactions/ledger/:portfolioId
 */
const getLedgerTransactions = async (req, res) => {
    const portfolioId = req.params.portfolioId;
    const userId = req.user.id;

    try {
        // Check ownership
        const { rows: portfolioRows } = await db.query('SELECT user_id FROM portfolios WHERE id = $1', [portfolioId]);
        if (portfolioRows.length === 0) {
            return res.status(404).json({ msg: 'Portfolio not found.' });
        }
        if (portfolioRows[0].user_id !== userId) {
            return res.status(403).json({ msg: 'You are not authorized to view these transactions.'});
        }

        const page = parseInt(req.query.page) || 1;
        const limit = parseInt(req.query.limit) || 10;
        const offset = (page - 1) * limit;

        // Filter transactions by portfolioId
        const transactionsResult = await db.query(
            'SELECT * FROM units_ledger WHERE portfolio_id = $1 ORDER BY transaction_date DESC LIMIT $2 OFFSET $3',
            [portfolioId, limit, offset]
        );

        // Get total count for THIS portfolio
        const totalResult = await db.query(
            'SELECT COUNT(*) FROM units_ledger WHERE portfolio_id = $1',
            [portfolioId]
        );
        
        res.json({
            transactions: transactionsResult.rows,
            totalItems: parseInt(totalResult.rows[0].count),
            currentPage: page,
            totalPages: Math.ceil(totalResult.rows[0].count / limit),
        });
    } catch (err) {
        console.error('DB Error in getLedgerTransactions:', err.message);
        res.status(500).send(err.message);
    }
};

module.exports = {
  createTransaction,
  getAssetTransactions,
  getLedgerTransactions // <-- Export the new function
};