const express = require('express');
const router = express.Router();
const { createTransaction, getAssetTransactions } = require('../controllers/transactionController');
const { protect, isInvestor } = require('../middleware/authMiddleware'); // <-- Use isInvestor

// All routes in this file are for INVESTORS ONLY
router.use(protect, isInvestor);

// @route   POST /api/transactions
// @desc    Handles all transaction types (Deposit, Withdraw, Buy, Sell)
router.post('/', createTransaction);

// @route   GET /api/transactions/:portfolioId
// @desc    Get all asset buy/sell transaction history (with pagination)
router.get('/:portfolioId', getAssetTransactions); // <-- Changed from '/assets'

module.exports = router;