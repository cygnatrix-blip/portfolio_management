import { useState, useEffect, useMemo, useCallback } from 'react';
import axios from 'axios';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

import {
    Box,
    Typography,
    Paper,
    Grid,
    CircularProgress,
    Table,
    TableBody,
    TableCell,
    TableContainer,
    TableHead,
    TableRow,
    Card,
    CardContent,
    Button
} from '@mui/material';

// Helper function to format a date to YYYY-MM-DD for reliable matching
const formatDateKey = (date) => {
    const d = new Date(date);
    let month = '' + (d.getMonth() + 1);
    let day = '' + d.getDate();
    const year = d.getFullYear();

    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [year, month, day].join('-');
}

const ClientDashboard = () => {
  const [clientData, setClientData] = useState(null);
  const [niftyData, setNiftyData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [refreshCount, setRefreshCount] = useState(0);

  const fetchAllData = useCallback(async () => {
    const token = localStorage.getItem('token');
    if (!token) {
      setLoading(false);
      return;
    }
    const config = { 
      headers: { Authorization: `Bearer ${token}` },
      timeout: 10000
    };

    try {
      const [clientRes, niftyRes] = await Promise.all([
          axios.get('http://localhost:5000/api/portal/me', config),
          axios.get('http://localhost:5000/api/market/nifty50', config)
      ]);
      
      console.log('📊 Client Data received');
      console.log('📈 Nifty Data received');
      
      setClientData(clientRes.data);
      setNiftyData(niftyRes.data);
      setError(null);

    } catch (error) {
      console.error('Error fetching dashboard data:', error);
      setError(`Failed to load data: ${error.response?.data?.message || error.message}`);
      if (error.response && error.response.status === 401) {
          localStorage.removeItem('token');
          window.location.reload();
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchAllData();
  }, [fetchAllData, refreshCount]);

  const handleRefresh = () => {
    setLoading(true);
    setRefreshCount(prev => prev + 1);
  };
  
  // FIXED normalized data calculation
  const normalizedData = useMemo(() => {
    if (!clientData || !clientData.navHistory || clientData.navHistory.length < 2 || !niftyData || niftyData.length === 0) {
      console.log('❌ Insufficient data for normalized chart');
      return [];
    }
    
    console.log('🔍 === DEBUG: Date Matching Analysis ===');
    
    // Log all dates from both datasets
    console.log('📅 NAV History dates:', clientData.navHistory.map(n => n.nav_date));
    console.log('📈 Nifty Data dates:', niftyData.map(n => n.date));

    // Check specific October 6th
    const oct6Nav = clientData.navHistory.find(n => n.nav_date === '2025-10-06' || formatDateKey(n.nav_date) === '2025-10-06');
    const oct6Nifty = niftyData.find(n => n.date === '2025-10-06' || formatDateKey(n.date) === '2025-10-06');
    
    console.log('🎯 October 6th Check:');
    console.log('   - NAV:', oct6Nav ? `Found: ${oct6Nav.nav_value}` : 'NOT FOUND');
    console.log('   - Nifty:', oct6Nifty ? `Found: ${oct6Nifty.price}` : 'NOT FOUND');

    try {
      // Create a map of nifty data with date keys
      const niftyMap = new Map();
      niftyData.forEach(item => {
        const date = item.date;
        if (date) {
          const dateKey = formatDateKey(date);
          niftyMap.set(dateKey, parseFloat(item.price));
        }
      });
      
      console.log('🗺️ Nifty Map entries (first 5):', Array.from(niftyMap.entries()).slice(0, 5));
      console.log('🗺️ Nifty Map has Oct 6:', niftyMap.has('2025-10-06'));

      const fundHistory = clientData.navHistory;
      
      // Sort NAV history chronologically
      const sortedNavHistory = [...fundHistory].sort((a, b) => 
        new Date(a.nav_date) - new Date(b.nav_date)
      );

      console.log('🔄 Finding ALL matching dates...');
      
      // Find ALL matching dates between NAV and Nifty data (REMOVED the date filter)
      const matchingData = sortedNavHistory
        .map(navPoint => {
          const dateKey = formatDateKey(navPoint.nav_date);
          const niftyPrice = niftyMap.get(dateKey);
          
          console.log(`   🔄 Checking ${dateKey}: NAV=${navPoint.nav_value}, Nifty=${niftyPrice}, Match=${!!niftyPrice}`);
          
          if (niftyPrice && !isNaN(niftyPrice)) {
            return {
              navDate: navPoint.nav_date,
              navValue: parseFloat(navPoint.nav_value),
              niftyPrice: niftyPrice,
              dateKey: dateKey
            };
          }
          return null;
        })
        .filter(Boolean);

      console.log('✅ ALL Matching data points found:', matchingData.length);
      console.log('✅ ALL Matching dates:', matchingData.map(m => m.dateKey));

      if (matchingData.length < 2) {
        console.log('❌ Not enough matching data points');
        return [];
      }

      // Use the first matching point as base for normalization
      const baseNav = matchingData[0].navValue;
      const baseNifty = matchingData[0].niftyPrice;

      console.log('🏁 Base values:', { 
        baseDate: matchingData[0].dateKey, 
        baseNav, 
        baseNifty 
      });

      // Calculate normalized performance for ALL matching points
      const result = matchingData.map((point) => ({
        date: new Date(point.navDate).toLocaleDateString('en-IN', { 
          month: 'short', 
          day: 'numeric',
          year: '2-digit'
        }),
        fundPerformance: ((point.navValue / baseNav) - 1) * 100,
        niftyPerformance: ((point.niftyPrice / baseNifty) - 1) * 100,
        raw: {
          nav: point.navValue,
          nifty: point.niftyPrice,
          date: point.dateKey
        }
      }));

      console.log('📊 Final normalized data:', result);
      return result;
      
    } catch (error) {
      console.error('💥 Error calculating normalized data:', error);
      return [];
    }
  }, [clientData, niftyData]);

  // All other functions remain the same
  const getCombinedChartData = () => {
     if (!clientData || !clientData.navHistory || !clientData.transactionHistory) return [];
    const portfolioDataMap = new Map();
    let unitsHeld = 0;
    let netInvestment = 0;
    clientData.navHistory.forEach(historyPoint => {
        const transactionsUpToDate = clientData.transactionHistory.filter(tx => new Date(tx.transaction_date) <= new Date(historyPoint.nav_date));
        unitsHeld = 0;
        netInvestment = 0;
        transactionsUpToDate.forEach(tx => {
            if(tx.transaction_type === 'DEPOSIT') {
                unitsHeld += parseFloat(tx.units);
                netInvestment += parseFloat(tx.amount);
            }
            if(tx.transaction_type === 'WITHDRAWAL') {
                unitsHeld -= parseFloat(tx.units);
                netInvestment -= parseFloat(tx.amount);
            }
        });
        const dateStr = new Date(historyPoint.nav_date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
        const portfolioValue = unitsHeld * parseFloat(historyPoint.nav_value);
        if (portfolioValue > 0.0001) portfolioDataMap.set(dateStr, { date: dateStr, portfolioValue, netInvestment });
    });
    clientData.navHistory.forEach(historyPoint => {
        const dateStr = new Date(historyPoint.nav_date).toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
        if (portfolioDataMap.has(dateStr)) {
            const existingData = portfolioDataMap.get(dateStr);
            existingData.nav = parseFloat(historyPoint.nav_value);
            portfolioDataMap.set(dateStr, existingData);
        }
    });
    return Array.from(portfolioDataMap.values());
  };
  
  const calculateAbsoluteReturn = () => {
    if (!clientData || !clientData.transactionHistory || clientData.transactionHistory.length === 0) return "N/A";
    let netInvestment = 0;
    clientData.transactionHistory.forEach(tx => {
        if(tx.transaction_type === 'DEPOSIT') netInvestment += parseFloat(tx.amount);
        else if (tx.transaction_type === 'WITHDRAWAL') netInvestment -= parseFloat(tx.amount);
    });
    if (netInvestment <= 0) return "N/A";
    const absoluteReturn = ((clientData.currentValue - netInvestment) / netInvestment) * 100;
    return absoluteReturn.toFixed(2);
  };

  if (loading) {
    return (
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
            <CircularProgress /><Typography sx={{ml: 2}}>Loading performance data...</Typography>
        </Box>
    );
  }

  if (error) {
    return (
      <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '80vh' }}>
        <Typography color="error">Error: {error}</Typography>
      </Box>
    );
  }

  if (!clientData || !clientData.transactionHistory || clientData.transactionHistory.length === 0) {
    return <Typography variant="h6" color="text.secondary" sx={{mt: 4, textAlign: 'center'}}>No portfolio data found.</Typography>;
  }

  const { clientName, totalUnits, currentValue, latestNav, transactionHistory } = clientData;
  const absoluteReturn = calculateAbsoluteReturn();
  const combinedChartData = getCombinedChartData();

  const MetricCard = ({ title, value }) => (
    <Card sx={{ height: '100%', textAlign: 'center' }}><CardContent><Typography sx={{ fontSize: 14 }} color="text.secondary" gutterBottom>{title}</Typography><Typography variant="h5" component="div">{value}</Typography></CardContent></Card>
  );

  return (
    <Box sx={{ flexGrow: 1, padding: { xs: 1, md: 2 } }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', mb: 2 }}>
        <Typography variant="h4" gutterBottom>Welcome, {clientName}!</Typography>
        <Button variant="contained" onClick={handleRefresh} disabled={loading}>
          Refresh Data
        </Button>
      </Box>
      
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}><MetricCard title="Your Current Value" value={`₹${currentValue.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`} /></Grid>
        <Grid item xs={12} sm={6} md={3}><MetricCard title="Your Total Units" value={totalUnits.toFixed(4)} /></Grid>
        <Grid item xs={12} sm={6} md={3}><MetricCard title="Current NAV" value={`₹${parseFloat(latestNav).toFixed(4)}`} /></Grid>
        <Grid item xs={12} sm={6} md={3}><MetricCard title="Absolute Return" value={`${absoluteReturn}%`} /></Grid>
      </Grid>

      <Paper sx={{ p: { xs: 1, md: 3 }, mb: 4 }}>
        <Typography variant="h5" gutterBottom>Performance History</Typography>
        <Box sx={{ height: 400 }}>
            {combinedChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={combinedChartData} margin={{ top: 5, right: 30, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="date" /><YAxis yAxisId="left" width={90} tickFormatter={(value) => `₹${value.toLocaleString('en-IN')}`} /><YAxis yAxisId="right" orientation="right" width={80} tickFormatter={(value) => `₹${value.toFixed(2)}`} /><Tooltip formatter={(value, name) => { if (name === 'NAV') return `₹${value.toFixed(4)}`; return `₹${value.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`; }} /><Legend /><Line yAxisId="left" type="monotone" dataKey="portfolioValue" stroke="#8884d8" strokeWidth={2} activeDot={{ r: 8 }} name="Portfolio Value" /><Line yAxisId="left" type="monotone" dataKey="netInvestment" stroke="#ff7300" strokeDasharray="5 5" name="Net Investment" /><Line yAxisId="right" type="monotone" dataKey="nav" stroke="#00C49F" strokeWidth={2} name="NAV" />
                    </LineChart>
                </ResponsiveContainer>
            ) : (<Box sx={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%'}}><Typography color="text.secondary">Not enough data for this chart.</Typography></Box>)}
        </Box>
      </Paper>

      <Paper sx={{ p: { xs: 1, md: 3 }, mb: 4 }}>
        <Typography variant="h5" gutterBottom>Performance vs. Nifty 50 (Normalized)</Typography>
        <Box sx={{ height: 400 }}>
            {normalizedData.length > 1 ? (
                <ResponsiveContainer width="100%" height="100%">
                    <LineChart data={normalizedData} margin={{ top: 5, right: 20, left: 20, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" />
                        <XAxis dataKey="date" />
                        <YAxis tickFormatter={(value) => `${value.toFixed(0)}%`} />
                        <Tooltip formatter={(value) => `${value.toFixed(2)}%`} />
                        <Legend />
                        <Line type="monotone" dataKey="fundPerformance" stroke="#8884d8" strokeWidth={2} name="Your Fund" dot={false} />
                        <Line type="monotone" dataKey="niftyPerformance" stroke="#82ca9d" strokeWidth={2} name="Nifty 50" dot={false} />
                    </LineChart>
                </ResponsiveContainer>
            ) : (
              <Box sx={{display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100%', flexDirection: 'column'}}>
                <Typography color="text.secondary" gutterBottom>
                  {normalizedData.length === 1 ? 
                    "Comparison chart requires at least two common data points between NAV history and Nifty 50." : 
                    "No common data found between NAV history and Nifty 50 for comparison."
                  }
                </Typography>
                <Button variant="outlined" onClick={handleRefresh} sx={{ mt: 2 }}>
                  Refresh Data
                </Button>
              </Box>
            )}
        </Box>
      </Paper>
      
      <Paper sx={{ p: { xs: 1, md: 3 } }}>
        <Typography variant="h5" gutterBottom>Your Transaction History</Typography>
        <TableContainer>
            <Table sx={{ minWidth: 650 }}><TableHead sx={{ backgroundColor: '#f5f5f5' }}><TableRow><TableCell>Date</TableCell><TableCell>Type</TableCell><TableCell align="right">Amount</TableCell><TableCell align="right">Units</TableCell></TableRow></TableHead><TableBody>{transactionHistory.map((tx, index) => (<TableRow key={index} sx={{ '&:last-child td, &:last-child th': { border: 0 } }}><TableCell>{new Date(tx.transaction_date).toLocaleDateString('en-IN')}</TableCell><TableCell>{tx.transaction_type}</TableCell><TableCell align="right">₹{parseFloat(tx.amount).toLocaleString('en-IN')}</TableCell><TableCell align="right">{parseFloat(tx.units).toFixed(4)}</TableCell></TableRow>))}</TableBody></Table>
        </TableContainer>
      </Paper>
    </Box>
  );
};

export default ClientDashboard;